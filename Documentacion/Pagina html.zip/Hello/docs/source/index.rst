.. Pia documentation master file, created by
   sphinx-quickstart on Tue May  9 20:34:44 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PIA's documentation!
===============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Modulos
=======

* Metadata
	**Descripcion** Interpretar metadatos de una imagen.	
	
	**Argumentos** Image path (str): Ruta de la imagen.
	         
	>>> python LAST.py metadata <Ruta de la imagen>

* ip
	**Descripcion** Realizar analisis de direcciones IP y puertos abiertos.

	**Argumentos** Ip (str): Direccion IP a analizar.

	>>> python LAST.py ip <Direccion IP>

* web 
	**Descripcion** Verificar si una pagina web esta en funcionamiento.

	**Argumentos** Url (str): URL de la pagina web.
	
	>>> python LAST.py web <URL de la pagina web>

	
* correo
	**Descripcion** Enviar un archivo de texto por correo electronico.

	**Argumentos** archivo (str): Archivo de texto a enviar. Las opciones disponibles son:			
			* 'domain_info'
			* 'metadatos'
			* 'IP_informe'

	>>> python LAST.py correo <Opcion de las listadas anteriormente>

* scrape
	**Descripcion** Se encarga de extraer informacon como el titulo de la pagina y los enlaces.

	**Argumentos** url (str): Argumento opcional que permite especificar la URL de la pagina web que se va a analizar.

	>>> python LAST.py scrape <URL de la pagina web>

	Si no se proporciona el argumento -url, se ejecutara con la URL predeterminada 'www.example.com'.

	>>> python LAST.py scrape 

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
